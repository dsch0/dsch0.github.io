﻿namespace MIS3033_HW8_AndrewSchmidt.Models
{
    public class Message
    {

        public string status {  get; set; }
        public string message { get; set; }

    }
}
