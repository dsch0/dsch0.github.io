﻿namespace MIS3033_LC_1108_AndrewSchmidt.Models
{
    public class Message
    {
        public string status { get; set; } = "success";

        public string message { get; set; } = "";


    }
}
