﻿namespace MIS3033_HW7_AndrewSchmidt.Models
{
    public class Message
    {
        public string status {  get; set; }
        public string message { get; set; }

    }
}
